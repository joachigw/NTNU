/**
 * Initializes the constants used to represent the different item categories.
 */
public enum ItemCategory
{
    FLOOR_LAMINATES,
    WINDOWS,
    DOORS,
    LUMBER,
}
